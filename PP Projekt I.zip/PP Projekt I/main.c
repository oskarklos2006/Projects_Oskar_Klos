#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ncurses.h>
#include <time.h>

#define WINDOW_HEIGHT 30
#define WINDOW_WIDTH 49
#define textLenght 100

#define C_CAR1 1
#define C_CAR2 2
#define C_CAR3 3

#define C_RIVER 4
#define C_FROG 5
#define C_HEADER 6
#define C_LANE 7
#define C_OBSTACLE 8
#define C_FINISH 9
#define C_WATER 10
#define C_SHIP1 11
#define C_LILY 12

#define nCars 4
#define nShips 8
#define nLilies 2


typedef struct
{
    int width, height;
    int lane_w, lane_h;
    char **lane;
    char **obstacle;
    int obstacle_w, obstacle_h;
} Area;

typedef struct
{
    int frog_x, frog_y;
    char frog;
} Frog;

typedef struct
{
    int car_x, car_y;
    int lenght;
    int color;
    int speed;
    int row;
} Car; 

typedef struct
{
    int ship_x, ship_y;
    int lenght;
    int color;
    int speed;
    int row;
} Ship; 

typedef struct
{
    int lily_x, lily_y;
    int lenght;
    int row;
    int speed;
    int color;
    int direction;
} Lily;

WINDOW *initCurses()
{
    // Initialization of ncurses
    initscr();
    noecho();
    cbreak();
    curs_set(0);
    nodelay(stdscr, TRUE);
    refresh();
    start_color();
    
    init_pair(C_WATER, COLOR_RED, COLOR_BLUE);
    init_pair(C_HEADER, COLOR_GREEN, COLOR_WHITE); 
    init_pair(C_FROG, COLOR_GREEN, COLOR_GREEN); 
    init_pair(C_FINISH, COLOR_MAGENTA, COLOR_GREEN); 
    init_pair(C_OBSTACLE, COLOR_RED, COLOR_BLUE); 
    init_pair(C_LANE, COLOR_YELLOW, COLOR_MAGENTA); 
    init_pair(C_CAR1, COLOR_RED, COLOR_RED); 
    init_pair(C_CAR2, COLOR_MAGENTA, COLOR_WHITE); 
    init_pair(C_CAR3, COLOR_YELLOW, COLOR_YELLOW); 
    init_pair(C_RIVER, COLOR_CYAN, COLOR_CYAN); 
    init_pair(C_SHIP1, COLOR_MAGENTA, COLOR_BLUE);
    init_pair(C_LILY, COLOR_GREEN, COLOR_CYAN);

    return newwin(WINDOW_HEIGHT, WINDOW_WIDTH, 2, 20);
}

void readMap(char *path, Area *area)
{
    FILE *file = fopen(path, "r");
    if (!file)
    {
        perror("Failed to open map file");
        exit(EXIT_FAILURE);
    }

    char line[textLenght];
    while (fgets(line, 100, file))
    {
        if (strlen(line) < 2)
            continue;

        if (strncmp(line, "map", 3) == 0)
        {
            sscanf(line + 4, "%d %d", &area->width, &area->height);
        }
        else if (strncmp(line, "lane", 4) == 0)
        {
            sscanf(line + 5, "%d %d", &area->lane_w, &area->lane_h);

            // ALLOCATE MEMORY
            area->lane = (char **)malloc(sizeof(char *) * area->lane_h);
            for (int i = 0; i < area->lane_h; i++)
                area->lane[i] = (char *)malloc(sizeof(char) * (area->lane_w + 1)); 

            // READ LANES
            for (int i = 0; i < area->lane_h; i++)
            {
                fgets(line, 100, file);

                for (int x = 0; x < area->lane_w; x++)
                {
                    area->lane[i][x] = line[x];
                }
                area->lane[i][area->lane_w] = '\0'; 

            }
        }
    }
    fclose(file);
}

void readObstacle(char *path1, Area *area)
{
 FILE *file = fopen(path1, "r");
    if (!file)
    {
        perror("Failed to open map file");
        exit(EXIT_FAILURE);
    }

    char line[textLenght];
    while (fgets(line, 100, file))
    {
        if (strlen(line) < 2)
            continue;

        else if (strncmp(line, "obstacle", 8)==0)
        {
            sscanf(line + 9, "%d %d", &area->obstacle_w, &area->obstacle_h);

            // ALLOCATE MEMORY
            area->obstacle = (char **)malloc(sizeof(char *) * area->obstacle_h);
            for (int i = 0; i < area->obstacle_h; i++)
                area->obstacle[i] = (char *)malloc(sizeof(char) * (area->obstacle_w + 1)); 

            // READ OBSTACLE
            for (int i = 0; i < area->obstacle_h; i++)
            {
                fgets(line, 100, file);

                for (int x = 0; x < area->obstacle_w; x++)
                {
                    area->obstacle[i][x] = line[x];
                }
                area->obstacle[i][area->obstacle_w] = '\0'; 
            }
        }
    }
    fclose(file);
}

void drawMap(WINDOW *win, Area *area)
{
    // DRAW FINISH LINE
    wattron(win, COLOR_PAIR(C_FINISH));
    for (int i = 0; i < area->width; i++)
    {
        mvwaddch(win, 1, i, ' ');
    }
    wattroff(win, COLOR_PAIR(C_FINISH));

    // DRAW BACKGROUND
    for (int y = 2; y < area->height; y++)
    {
        for (int x = 0; x < area->width; x++)
        {
            if(y == 6 || y == WINDOW_HEIGHT -6) 
            {
                wattron(win, COLOR_PAIR(C_RIVER));
                mvwaddch(win, y, x, ' ');
                wattroff(win, COLOR_PAIR(C_RIVER));
            }
            else{
                wattron(win, COLOR_PAIR(C_WATER));
                mvwaddch(win, y, x, ' ');
                wattroff(win, COLOR_PAIR(C_WATER));
            }             
        }
    }

    // DRAW LANES
    wattron(win, COLOR_PAIR(C_LANE));
    for (int y = 0; y < area->lane_h; y++)
    {
        for (int x = 0; x < area->lane_w; x++)
        {
            mvwaddch(win, (WINDOW_HEIGHT / 2) + 2 + y, x, area->lane[y][x]);
            mvwaddch(win, (WINDOW_HEIGHT / 2) - 6 + y, x, area->lane[y][x]);
        }
    }
    wattroff(win, COLOR_PAIR(C_LANE));

    box(win, 0, 0);
    wrefresh(win);
}

void drawObstacle(WINDOW *win, Area *area)
{
    // Draw obstacle
    const int obstacle_pos1 = (WINDOW_HEIGHT - 15);
    const int obstacle_pos2 = (WINDOW_HEIGHT - 7);
    const int obstacle_pos3 = (WINDOW_HEIGHT - 5);
    const int obstacle_pos4 = (WINDOW_HEIGHT - 23);
    const int obstacle_pos5 = (WINDOW_HEIGHT - 25);

    wattron(win, COLOR_PAIR(C_OBSTACLE));
    for (int x = 1; x < area->obstacle_w; x++)
    {
        mvwaddch(win, obstacle_pos1, x, area->obstacle[0][x]);
        mvwaddch(win, obstacle_pos2, x, area->obstacle[1][x]);
        mvwaddch(win, obstacle_pos3, x, area->obstacle[2][x]);
        mvwaddch(win, obstacle_pos4, x, area->obstacle[0][x]);
        mvwaddch(win, obstacle_pos5, x, area->obstacle[1][x]);
    }
    wattroff(win, COLOR_PAIR(C_OBSTACLE));
}

void freeMap(Area *area)
{
    // FREEE THE MEMORY FOR LANE
    for (int i = 0; i < area->lane_h; i++)
    {
        free(area->lane[i]);
    }
    free(area->lane);

    // FREE THE MEMORY FOR OBSTACLE
    for (int i = 0; i < area->obstacle_h; i++)
    {
        free(area->obstacle[i]);
    }
    free(area->obstacle);
}



void readFrog(char *path, Frog *frog)
{
    FILE *file = fopen(path, "r");
    if (!file)
    {
        perror("Failed to open Frog file");
        exit(EXIT_FAILURE);
    }

    char line[textLenght];

    while (fgets(line, sizeof(line), file))
    {
        if (strlen(line) < 2)
            continue;

        if (strncmp(line, "frog", 4) == 0)
        {
            sscanf(line + 5, "%c", &frog->frog);
        }
    }
    fclose(file);
}

void drawFrog(WINDOW *win, Frog *frog)
{
    wattron(win, COLOR_PAIR(C_FROG));
    mvwaddch(win, frog->frog_y, frog->frog_x, frog->frog);
    wattroff(win, COLOR_PAIR(C_FROG));
}

void handleFrogMovement(int *last_key, Frog *frog, Lily *lily)
{
    int ch = getch();

    static int is_on_lily = 0;    
    static int current_lily = -1; 

    int old_frog_x = frog->frog_x;
    int old_frog_y = frog->frog_y;

    if (ch != *last_key)
    {
        switch (ch)
        {
        case 'W':
        case 'w':
            if (frog->frog_y > 1)
                frog->frog_y--;
            break;
        case 'S':
        case 's':
            if (frog->frog_y < WINDOW_HEIGHT - 2)
                frog->frog_y++;
            break;
        case 'A':
        case 'a':
            if (frog->frog_x > 1)
                frog->frog_x--;
            break;
        case 'D':
        case 'd':
            if (frog->frog_x < WINDOW_WIDTH - 2)
                frog->frog_x++;
            break;
        default:
            break;
        }
        *last_key = ch; 
    }

    // FROG ON LILY MOVEMENT (SPEED)
    if (frog->frog_y == WINDOW_HEIGHT - 6 || frog->frog_y == WINDOW_HEIGHT - 24)
    {
        for (int i = 0; i < 2; i++)
        {
            if (frog->frog_x >= lily[i].lily_x && frog->frog_x <= lily[i].lily_x + lily[i].lenght)
            {
                is_on_lily = 1;
                current_lily = i;
                break;
            }
        }

        if (current_lily == -1) 
        {
            frog->frog_y = old_frog_y;
        }
    }
    else
    {
        is_on_lily = 0;   
        current_lily = -1;
    }

    if (is_on_lily && current_lily != -1)
    {
        if (lily[current_lily].direction == 1)
            frog->frog_x += lily[current_lily].speed;
        else
            frog->frog_x -= lily[current_lily].speed;
    }
}

void checkCollisionObstacle(int *collision, Area *area, Frog *frog, Lily *lily)
{
    const int obstacle_rows[] = {WINDOW_HEIGHT - 15, WINDOW_HEIGHT - 7, WINDOW_HEIGHT - 5, WINDOW_HEIGHT - 23, WINDOW_HEIGHT - 25};
    int rows_y[] = {WINDOW_HEIGHT - 6, WINDOW_HEIGHT-24};
    *collision = 0; 

    for (int i = 0; i < 7; i++)
    {
        if (frog->frog_y == obstacle_rows[i])
        {
            if (area->obstacle[i % area->obstacle_h][frog->frog_x] == 'o')
            {
                *collision = 1;
                break;
            }
        }
        for (int i=0; i<2; i++)
        {
            if (frog->frog_y == rows_y[i])
                {
                    if (frog->frog_x >= lily[i].lily_x && frog->frog_x <= lily[i].lily_x + lily[i].lenght)
                    {
                        *collision = 0;
                    }
                    else
                    *collision = 1;
                }
        }
    }
}

void checkFrogCarInteraction(Frog *frog, Car *car)
{
    for (int i = 0; i < nCars; i++)
    {
        if (frog->frog_y == car[i].car_y)
        {
            if (i % 2 == 0)
            {
                if(frog->frog_x < car[i].car_x -5  && frog->frog_x > car[i].car_x - 8)
                car[i].speed = 0;
            }
            else if (i % 2 == 1)
            {
                if(frog->frog_x > car[i].car_x + car[i].lenght + 5 && frog->frog_x < car[i].car_x + car[i].lenght + 8)
                car[i].speed = 0;
            }
        }
        else
        {
            if (car[i].speed == 0)
                car[i].speed = rand() % 3 + 1; 
        }
    }
}

void checkAndUpdateMove(int *move_count, int old_frog_x, int old_frog_y, Area *area, Frog *frog, Lily *lily)
{
    int collision;
    checkCollisionObstacle(&collision, area , frog, lily);

    if (collision)
    {
        frog->frog_x = old_frog_x;
        frog->frog_y = old_frog_y;
    }

    // FROG ON LILY MOVEMENT (MOVE_COUNT)
    static int is_on_lily = 0; 
    if (frog->frog_y == WINDOW_HEIGHT - 6 || frog->frog_y == WINDOW_HEIGHT - 24)
    {
        for (int i = 0; i < 2; i++)
        {
            if (frog->frog_x >= lily[i].lily_x && frog->frog_x <= lily[i].lily_x + lily[i].lenght)
            {
                is_on_lily = 1;
                break;
            }
        }
    }
    else
    {
        is_on_lily = 0;
    }

    if (!is_on_lily && (old_frog_x != frog->frog_x || old_frog_y != frog->frog_y))
    {
        (*move_count)++;
    }
}

void moveFrog(int *last_key, int *move_count,WINDOW *win, Area *area, Frog *frog, Lily *lily)
{
    int old_frog_x = frog->frog_x;
    int old_frog_y = frog->frog_y;

    handleFrogMovement(last_key, frog, lily); 
    checkAndUpdateMove(move_count, old_frog_x, old_frog_y, area, frog, lily); 
}



void createCar(WINDOW *win, Car *car)
{
    srand(time(0));
    int rows_y[] = {10, 12, 18, 20}; 

    for (int i = 0; i < nCars; i++) 
    {
        if(i%2==1)
        {
            car[i].car_y = rows_y[i]; 
            car[i].speed = rand() % 3 + 1; 
            car[i].color = rand() % 5 + 1; 
            car[i].lenght = rand() % 7 + 3;
            car[i].car_x = -car[i].lenght;
        }
        else 
        {
            car[i].car_y = rows_y[i];  
            car[i].car_x = WINDOW_WIDTH;
            car[i].speed = rand() % 3 + 1; 
            car[i].color = rand() % 5 + 1; 
            car[i].lenght = rand() % 7 + 3; 
        }
    }
}

void drawCar(WINDOW *win, Car *car)
{
    for (int i = 0; i < nCars; i++)  
    {
        wattron(win, COLOR_PAIR(car[i].color));
        for (int j = 0; j < car[i].lenght; j++)
        {
         
            if(car[i].car_x + j < 1 || car[i].car_x + j + 2 > WINDOW_WIDTH ) continue;   mvwaddch(win, car[i].car_y, car[i].car_x + j, ' ');
        }
        wattroff(win, COLOR_PAIR(car[i].color));
    }
}

void updateCarPositions(Car *car)
{
    for (int i = 0; i < nCars; i++)  
    {
        if(i%2==1)
        {
            car[i].car_x += car[i].speed;  
        
            if (car[i].car_x > WINDOW_WIDTH )
            {
                car[i].car_x = 1 - car[i].lenght;
                car[i].color = rand() % 5 + 1;
                car[i].lenght = rand() % 7 + 3;
                car[i].speed=rand() % 2 + 1;
            }
        }
        else 
        {
            car[i].car_x -= car[i].speed;

            if(car[i].car_x + car[i].lenght  < 0)
            {
            car[i].car_x = WINDOW_WIDTH ;
            car[i].color = rand() % 5 + 1; 
            car[i].lenght = rand() % 7 + 3; 
            car[i].speed=rand() % 2 + 1;
            }
        }
    }
}



void createShip(WINDOW *win, Ship *ship)
{
    srand(time(0));
    int rows_y[] = {2, 3, 4, 8, 14, WINDOW_HEIGHT - 4, WINDOW_HEIGHT - 8, WINDOW_HEIGHT - 14};

    for (int i = 0; i < nShips; i++)
    {
        if(i%2==1)
        {
            ship[i].ship_y = rows_y[i];
            ship[i].ship_x = -ship[i].lenght - 1;
            ship[i].speed = rand() % 3 + 1; 
            ship[i].color = 11; 
            ship[i].lenght = rand() % 7 + 3; 
        }
        else 
        {
            ship[i].ship_y = rows_y[i];  
            ship[i].ship_x = WINDOW_WIDTH-1;
            ship[i].speed = rand() % 3 + 1; 
            ship[i].color = 11;
            ship[i].lenght = rand() % 7 + 3; 
        }
    }
}

void drawShip(WINDOW *win, Ship *ship)
{
    for (int i = 0; i < nShips; i++) 
    {
        wattron(win, COLOR_PAIR(ship[i].color));
        for (int j = 1; j <= ship[i].lenght; j++)  
        {
        if(ship[i].ship_x + j < 1 || ship[i].ship_x + j + 2 > WINDOW_WIDTH) continue; mvwaddch(win, ship[i].ship_y, ship[i].ship_x + j, '=');
        }
        wattroff(win, COLOR_PAIR(ship[i].color));
    }
}

void updateShipPositions(Ship *ship)
{
    for (int i = 0; i < nShips; i++)  
    {
        if(i%2==1)
        {
            ship[i].ship_x += ship[i].speed;
        
            if (ship[i].ship_x > WINDOW_WIDTH)
            {
            ship[i].ship_x = 1 - ship[i].lenght;  
            ship[i].ship_x = -(ship[i].lenght+1);
            ship[i].speed = rand() % 3 + 1; 
            ship[i].color = 11;
            ship[i].lenght = rand() % 7 + 3;
            }
        }
        else 
        {
            ship[i].ship_x -= ship[i].speed;  
            if(ship[i].ship_x + ship[i].lenght + 1 < 0)
            {
            ship[i].ship_x = WINDOW_WIDTH;
            ship[i].speed = rand() % 3 + 1;
            ship[i].color = 11; 
            ship[i].lenght = rand() % 7 + 3;
            }
        }
    }
}



void createLily(WINDOW *win, Lily *lily)
{
    int rows_y[] = {6, WINDOW_HEIGHT - 6};

    for (int i = 0; i < nLilies; i++)
    {
        lily[i].lily_y = rows_y[i];
        lily[i].lily_x = 0;
        lily[i].speed = 1;
        lily[i].color = 12;
        lily[i].lenght = 4;
        lily[i].direction = 1;
    }
}

void drawLily(WINDOW *win, Lily *lily)
{
    for (int i = 0; i < nLilies; i++)
    {
        wattron(win, COLOR_PAIR(lily[i].color));
        for (int j = 1; j <= lily[i].lenght; j++)
        {
            if (lily[i].lily_x + j < 1 || lily[i].lily_x + j + 2 > WINDOW_WIDTH) continue;
            mvwaddch(win, lily[i].lily_y, lily[i].lily_x + j, 'O');
        }
        wattroff(win, COLOR_PAIR(lily[i].color));
    }
}

void updateLilyPositions(Lily *lily)
{
    // BOUNCING
    for (int i = 0; i < nLilies; i++) {
        if (lily[i].direction == 1) {
            lily[i].lily_x += lily[i].speed;
        } 
        else {
            lily[i].lily_x -= lily[i].speed;
        }

        if (lily[i].lily_x + lily[i].lenght >= WINDOW_WIDTH-2) {
            lily[i].direction = -1;
        }
        if (lily[i].lily_x <= 0) {
            lily[i].direction = 1;
        }
    }
}



void header(int move_count, float time, Area *area)
{
    attron(COLOR_PAIR(C_HEADER));
    mvprintw(WINDOW_HEIGHT/2, WINDOW_WIDTH + 20 + (area->width - strlen(" Oskar Klos, 203708 ")) / 2, " Oskar Klos, 203708 ");
    mvprintw(1+WINDOW_HEIGHT/2, WINDOW_WIDTH + 20 + (area->width - strlen(" Welcome to Frogger Game ")) / 2, " Welcome to Frogger Game ");

    // TIMER
    char tmp[50];
    snprintf((char*)&tmp, 50, " Moves: %d in time: %.1fs ", move_count, time);
    mvprintw(2+WINDOW_HEIGHT/2, WINDOW_WIDTH + 20 + (area->width - strlen(tmp))/2, "%s", tmp);
    attroff(COLOR_PAIR(C_HEADER));
    refresh();
}

void playorquit(WINDOW *win, int *game_over)
{
    if(*game_over == 1)
    {
        attron(COLOR_PAIR(C_HEADER));
        mvprintw(4 + WINDOW_HEIGHT / 2, 20 + WINDOW_WIDTH + (WINDOW_WIDTH - strlen("Press 'P' to Play Again. ")) / 2, "Press 'P' to Play Again.");
        mvprintw(5+WINDOW_HEIGHT / 2, 20 + WINDOW_WIDTH + (WINDOW_WIDTH - strlen("Press 'Q' to quit. ")) / 2, "Press 'Q' to quit.");
        attroff(COLOR_PAIR(C_HEADER));
    }
}

void resetGame(WINDOW *win, int *move_count, int *game_over, float *time, Frog *frog, Car *car, Lily *lily, Ship *ship, Area *area)
{
    *move_count = 0;
    *time = 0;
    *game_over = 0;

    frog->frog_x = WINDOW_WIDTH / 2;
    frog->frog_y = WINDOW_HEIGHT - 2;

    createCar(win, car);
    createShip(win, ship);
    createLily(win, lily);

    wclear(win);
    clear();
    refresh();

    drawMap(win, area);
    drawObstacle(win, area);
    drawLily(win, lily);
    drawFrog(win, frog);
    drawCar(win, car);
    drawShip(win, ship);
    header(*move_count, *time, area);
    wrefresh(win);
}
 
void endgame(WINDOW *win, int *game_over, Frog *frog, Car *car, Ship *ship)
{
    if (frog->frog_y == 1) 
    {
        wclear(win);
        *game_over = 1;

        attron(COLOR_PAIR(C_HEADER));
        mvprintw(3+WINDOW_HEIGHT / 2, 20 + WINDOW_WIDTH + (WINDOW_WIDTH - strlen("Congratulations, you win!")) / 2, "Congratulations, you win!");
        attroff(COLOR_PAIR(C_HEADER));
        refresh();
    }
    // FROG COLLISION WITH CAR OR SHIP
    else 
    {
        for (int i = 0; i < nShips; i++) 
        {
            if ((frog->frog_y == car[i].car_y && 
                frog->frog_x >= car[i].car_x && 
                frog->frog_x < car[i].car_x + car[i].lenght) || (frog->frog_y == ship[i].ship_y &&
                    frog->frog_x >= ship[i].ship_x &&
                    frog->frog_x < ship[i].ship_x + ship[i].lenght)) 
            {
                wclear(win);

                *game_over = 1;

                attron(COLOR_PAIR(C_HEADER));
                mvprintw(3+WINDOW_HEIGHT / 2, 20 + WINDOW_WIDTH + (WINDOW_WIDTH - strlen("Sorry, you Lose!")) / 2, "Sorry, you lose!");
                attroff(COLOR_PAIR(C_HEADER));
                refresh();
                break;
            }
        }
    }
}

int main()
{
    Area area;
    Frog frog;
    Car car[4];
    Ship ship[8];
    Lily lily[2];
    readMap("./map.txt", &area);
    readObstacle("./obstacle.txt", &area);
    readFrog("./frog.txt", &frog);

    WINDOW *win = initCurses();

    int move_count = 0;
    float time = 0;
    header(move_count, time, &area);

    frog.frog_x = WINDOW_WIDTH / 2;
    frog.frog_y = WINDOW_HEIGHT - 2;

    createCar(win, car);
    createShip(win, ship);
    createLily(win, lily);

    int last_key = 0;
    int game_over = 0;

    while (1)
    {
        if (!game_over)
        {
            moveFrog(&last_key, &move_count, win, &area, &frog, lily);
            checkFrogCarInteraction(&frog, car);
            updateCarPositions(car);
            updateShipPositions(ship);
            updateLilyPositions(lily);

            drawMap(win, &area);
            drawObstacle(win, &area);
            drawLily(win, lily);
            drawFrog(win, &frog);
            drawCar(win, car);
            drawShip(win, ship);
            header(move_count, time, &area);
        }
        else
        {
            int ch = getch();
            if (ch == 'Q' || ch == 'q')
                break;
            else if (ch == 'P' || ch == 'p')
            {
                resetGame(win, &move_count, &game_over, &time, &frog, car, lily, ship, &area);
            }
        }

        wrefresh(win);

        box(win, 0, 0);
        endgame(win, &game_over, &frog, car, ship);
        playorquit(win, &game_over);

        time += 0.05;
        usleep(50000);
    }
    freeMap(&area);
    delwin(win);
    endwin();

    return 0;
}